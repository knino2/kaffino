To manually import the widgets (they will be imported if you've chosen the automatic import) please:

1. Install & Activate the theme as per the "First Steps" section in the Documentation
2. Install & Activate this plugin https://wordpress.org/plugins/widget-settings-importexport/
3. Navigate to Tools -> Widget Settings Import and upload the file you need.